<div>
    <button type="submit" {{ $attributes }} class="btn btn-info">
        <i class="fa fa-search"></i></button>
</div>