    <button class="btn btn-link btn-sm" id="btn-edit-{{ $item->id }}-{{ $major->major_code }}"
        onclick="edit_col({{ $item->id }},'{{ $major->major_code }}')">{{ $amount['amount'] }} 
    </button>

    <div class="input-group input-group-sm d-none edit-row-{{ $item->id }}" id="col-input-cont-{{ $item->id }}-{{ $major->major_code }}">
      <input type="text" class="form-control" 
      value="{{ $amount['amount'] }}" 
      id="col-input-{{ $item->id }}-{{ $major->major_code }}"
      onchange="save_col({{ $amount['id'] }},'{{ $major->major_code }}')">
    </div>

@if($loop->index==0)
@push('scripts')
<script>
      function edit_col(id,code){
          $(`#btn-edit-${id}-${code}`).addClass('d-none');
          $(`#col-input-cont-${id}-${code}`).removeClass('d-none');
      }

      function save_col(id,code){
        var amount = $(`#col-input-${id}-${code}`).val();

        $.ajax({
            url:"{{ route('finance.budget.dev.plan.b3.update_col') }}",
            type:"post",
            data:{'id':id,'amount':amount},
            success:function(res){
              $(`#btn-edit-${id}-${code}`).removeClass('d-none');
              $(`#col-input-cont-${id}-${code}`).addClass('d-none');
              
              if(res.result==200){
                toastr['success'](res.msg);
              }else{
                toastr['error'](res.msg);
              }

            },
            error:function(err){
              console.log(err);
            }
        });
      }

      function edit_row(id,code){
          $(`#btn-edit-${id}-${code}`).removeClass('d-none');
          $(`#col-id-${id}-${code}`).addClass('d-none');
      }
</script>
@endpush
@endif