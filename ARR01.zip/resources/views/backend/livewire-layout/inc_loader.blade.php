<div wire:loading class="spinner-border spinner-border-sm text-{{ isset($color) ? $color : 'secondary' }}"  role="status">
  <span class="sr-only">Loading...</span>
</div>