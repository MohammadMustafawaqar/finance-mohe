<div style="display:inline;">
    <button {{ $attributes }} class="btn btn-danger btn-sm">
        <i class="fas fa-times"></i></button>
</div>