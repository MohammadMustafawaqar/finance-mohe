<div>
    <button type="submit" {{ $attributes }} class="btn btn-info">
        <i class="fa fa-save"></i>&nbsp; 
        {{ $slot }}
    </button>
</div>